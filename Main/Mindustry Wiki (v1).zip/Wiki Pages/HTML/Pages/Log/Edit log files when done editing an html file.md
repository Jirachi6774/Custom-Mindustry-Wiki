# Hey there =)

<style>
    body {
        font-family: Font;
        user-select: none;
    }

    h1 {
        color: #FFD27E;
        font-weight: bold;
        font-family: Font;
        transition: all 1s;
    }

    h1:hover {
        color: #F15454;
        cursor: pointer;
    }

    @font-face {
        font-family: Font;
        src: url('../../../../Assets/Misc/Fonts/Font.ttf')
    }

    blockquote {
        border-left-color: #FFD27E;
        background-color: rgba(255, 210, 128, 0.5);
        color: white;
        transition: all 1s;
    }

    blockquote:hover {
        border-left-color: #F15454;
        background-color: rgba(241, 84, 84, 0.50);
        color: white;
        text-shadow: 0 0 4px #F15454;
        cursor: pointer;
    }
</style>

Document name says it all, you don't have to open me.
> There is no reason to open this document.

> It is not allowed to Delete this document though.