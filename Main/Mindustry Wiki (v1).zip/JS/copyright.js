//Copyright Update Script//
type = "text/javascript" >
    document.write("2017 - " + new Date().getFullYear());